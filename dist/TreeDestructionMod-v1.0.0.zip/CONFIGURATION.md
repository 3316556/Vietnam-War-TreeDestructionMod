﻿# Configure Tree Destruction Mod

No user configuration is required.

## MelonPreferences

Most mods create preferences automatically only if they need them. If this mod uses MelonPreferences, the settings will appear after the game has launched once with the mod installed.

Preference file location:

`	ext
VietnamWar\UserData\MelonPreferences.cfg
`

Do not ship a pre-filled MelonPreferences.cfg to users; it can overwrite settings from other mods.
